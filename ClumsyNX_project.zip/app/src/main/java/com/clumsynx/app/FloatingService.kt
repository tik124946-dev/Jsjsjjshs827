package com.clumsynx.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.net.VpnService
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

/** Кнопка на экране: квадрат с паузой. Зелёная — ClumsyNX работает, красная — выключен или интернет остановлен. */
class FabView(ctx: Context) : View(ctx) {
    var green = false
    var timerOn = false
    var remain = 0
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#111827") }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val sw = w * 0.045f
        stroke.strokeWidth = sw
        stroke.color = if (green) Color.parseColor("#1FBF4B") else Color.parseColor("#E5171F")
        val r = w * 0.26f
        val rect = RectF(sw, sw, w - sw, w - sw)
        c.drawRoundRect(rect, r, r, fill)
        c.drawRoundRect(rect, r, r, stroke)
        val cx = w / 2
        val cy = w / 2 - if (remain > 0) w * 0.05f else 0f
        if (green) {
            val bw = w * 0.1f
            val bh = w * 0.34f
            c.drawRoundRect(RectF(cx - bw * 1.5f, cy - bh / 2, cx - bw * 0.5f, cy + bh / 2), bw / 3, bw / 3, white)
            c.drawRoundRect(RectF(cx + bw * 0.5f, cy - bh / 2, cx + bw * 1.5f, cy + bh / 2), bw / 3, bw / 3, white)
        } else {
            val t = w * 0.19f
            val path = Path()
            path.moveTo(cx - t * 0.7f, cy - t)
            path.lineTo(cx + t, cy)
            path.lineTo(cx - t * 0.7f, cy + t)
            path.close()
            c.drawPath(path, white)
        }
        if (remain > 0) {
            txt.textSize = w * 0.2f
            c.drawText("$remain", cx, w * 0.82f, txt)
        }
        if (timerOn) {
            val bx = w * 0.8f
            val by = w * 0.8f
            val br = w * 0.12f
            c.drawCircle(bx, by, br, fill)
            line.strokeWidth = w * 0.02f
            c.drawCircle(bx, by, br, line)
            c.drawLine(bx, by, bx, by - br * 0.6f, line)
            c.drawLine(bx, by, bx + br * 0.45f, by, line)
        }
    }
}

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var fab: FabView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var lastX = 40
    private var lastY = 300
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 300) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        build()
        return START_STICKY
    }

    private fun goForeground() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("fab", "ClumsyNX", NotificationManager.IMPORTANCE_MIN))
            val n = Notification.Builder(this, "fab")
                .setSmallIcon(android.R.drawable.ic_media_pause)
                .setContentTitle("ClumsyNX")
                .setContentText("Плавающая кнопка активна")
                .build()
            startForeground(7, n)
        } catch (e: Exception) { }
    }

    private fun build() {
        removeView()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (Store(this).fabSize * resources.displayMetrics.density).toInt()
        val v = FabView(this)
        val l = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        l.x = lastX
        l.y = lastY
        lp = l
        fab = v
        attach(v)
        try {
            wm.addView(v, l)
        } catch (e: Exception) {
            stopSelf()
            return
        }
        refresh()
        h.removeCallbacks(tick)
        h.post(tick)
    }

    private fun attach(v: View) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var down = 0L
        v.setOnTouchListener { _, e ->
            val l = lp
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = l?.x ?: 0; oy = l?.y ?: 0
                    moved = false; down = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved && l != null) {
                        l.x = ox + dx.toInt(); l.y = oy + dy.toInt()
                        lastX = l.x; lastY = l.y
                        try { wm.updateViewLayout(fab, l) } catch (ex: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (System.currentTimeMillis() - down > 700) vpnCmd(this, "STOP") else toggle()
                    }
                    true
                }
                else -> false
            }
        }
    }

    /** Нажатие: включить / поставить на паузу / продолжить. Долгое нажатие — полностью выключить. */
    private fun toggle() {
        if (!VpnState.running.value) {
            try {
                if (VpnService.prepare(this) == null) vpnCmd(this, null) else openApp()
            } catch (e: Exception) { openApp() }
        } else {
            vpnCmd(this, if (VpnState.paused.value) "RESUME" else "PAUSE")
        }
    }

    private fun openApp() {
        try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    private fun refresh() {
        val v = fab ?: return
        val running = VpnState.running.value
        v.visibility = if (running) View.VISIBLE else View.GONE
        val paused = VpnState.paused.value
        val now = System.currentTimeMillis()
        v.green = running && !paused
        var rem = 0
        if (paused && VpnState.pauseEnd > now) rem = ((VpnState.pauseEnd - now) / 1000).toInt() + 1
        else if (running && !paused && Params.effectEnd > now) rem = ((Params.effectEnd - now) / 1000).toInt() + 1
        v.remain = rem
        val st = Store(this)
        v.timerOn = st.pauseSec > 0 || st.effectSec > 0
        v.invalidate()
    }

    private fun removeView() {
        try { fab?.let { wm.removeView(it) } } catch (e: Exception) { }
        fab = null
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        removeView()
        super.onDestroy()
    }
}
